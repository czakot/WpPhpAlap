<header>
    <span>Könyv admin</span>
    <span class="header-right">
				<span><?=$_SESSION["user_data"]["name"]?></span>
				<a href="?logout=1">Kilépés</a>
			</span>
</header>