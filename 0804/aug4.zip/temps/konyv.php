<h1>Új könyv</h1>

<form action="" method="POST" id="urlap">
    <label for="name">Cím:</label>
    <input type="text" name="name" id="name">
    <label for="lead">Bemutató:</label>
    <textarea id="lead" name="lead"></textarea>

    <button>Mentés</button>
</form>

<?php
