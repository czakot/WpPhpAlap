<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <meta name="description" content="plüss webáruház termék listája">
    <meta name="keywords" content="plüss, plüssök, kutyaplüss">
    <meta name="robots" content="index,follow">

    <link rel="stylesheet" type="text/css" href="css/admin.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/a366c8f12a.js" crossorigin="anonymous"></script>
</head>