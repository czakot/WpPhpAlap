<nav>
    <a href="?menu=raktarlista">Raktár</a>
    <a href="?menu=termeklista">Termék</a>
    <a href="?menu=raktartetellista">Készlet</a>
</nav>