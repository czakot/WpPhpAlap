<?php
class raktar
{
    //ide tedd a __construct-ot és add át neki a $connection-t

    //írd meg a get_list metódust, bemenetnek használj $params tömböt és legyen egy where mezője amiből generálod a where feltételt

    //írd meg a save metódust
    //ha a kapott id 0 akkor INSERT ha nagyobb mint 0 akkor UPDATE legyen

    //írd meg a load_item_by_id metódust, bemeneti paraméternek használj tömböt, a $params["id"]-t tedd a lekérésbe WHERE feltételbe. A kapott tömböt add vissza

    //írd meg a delete metódust, törölje a kapott bemenő id alapján a sort az adatbázisból
}