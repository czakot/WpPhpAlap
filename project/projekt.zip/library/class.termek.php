<?php


class termek
{
    //ugyanúgy kell megcsinálni mint a raktar osztályt
}